public class FirstProgram{
	public static void main(String[] args){
		System.out.println("My name is Loai Zaidan");
		System.out.println("I am 20 years old");
		System.out.println("My hometown is Ramallah, Palestine");
	}
}